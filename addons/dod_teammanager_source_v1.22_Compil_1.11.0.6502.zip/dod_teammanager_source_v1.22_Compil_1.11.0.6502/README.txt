//////////////////////////////////////////////////////////////////////////////////////////////////
//
//
//    Attention!!! addon_dodtms_weaponadmin est une séparation de addon_dodtms_classrest qui est défectueux mais il se configure toujours dans le même fichier cfg!!!
//
//
//
//////////////////////////////////////////////////////////////////////////////////////////////////








//////////////////////////////////////////////////////////////////////////////////////////////////
//
// DoD TeamManager Source v1.2 README
//
// Created 16th January 2010
// by FeuerSturm (FeuerSturm@dodsourceplugins.net / www.dodsourceplugins.net)
//
//////////////////////////////////////////////////////////////////////////////////////////////////


1) Introduction:
================

First of all I'd like to thank all Beta Testers over at www.dodsourceplugins.net
for ideas for new and existing features, finding bugs and general testing on their
production servers within the last 9 months from beta1 to RC3v2.

The DoD TeamManager Source (in short DoD TMS) is an all-in-one solution for all
DoD:S server administrators.
It offers almost all that you'll need to successfully administer your gameserver
with ease and fun as most of the features are completely automated.



2) Features:
============

* General Features
	- complete Multilanguage-Support (en, de, es, fr, chi & pt already included!)
	- Modularization! All Addons are optional, don't run what you don't need!
	- each Addon uses it's own config file that contains all convars within
	  the folder "\orangebox\dod\cfg\dod_teammanager_source\" on your gameserver.

As of Version 1.2 the DoD TMS consists of the Base plugin and 10 addons,
you can find a short description of each addon's features below:

* DoD TMS Base Plugin (dod_teammanager_source.sp/.smx)
	- team join control to keep teams even
	- automatic team assignment if full team was selected
	- lock team Spectators for public players
	- smooth team switch without death for all players
	- provides/shares natives and functions for all other Addons

* AFK Manager Addon (addon_dodtms_afkmanager.sp/.smx)
	- moves players that are AFK in Spawn to team Specators
	- kicks AFK players after definable time
	- kicks idle players (that connect but don't join a team)
	- displays menu before sending players to Spec to be sure they aren't active
	- AFK players can be blinded if Team Spectators is usually blocked
	- Admin are immune to being kicked for being AFK

* Anti-VoiceCommandSpam Addon (addon_dodtms_antivcmds.sp/.smx)
	- prevent people from spamming voice commands like "Go! Go! Go!"
	- maximum number of allowed voice-commands per life can be set
	- minimum time between voice-command reuse can be specified
	- Admins can always use as many VCs as they like

* AutoTeamBalance Addon (addon_dodtms_autobalance.sp/.smx)
	- keeps team size balanced
	- can switch players on death or after fixed delay time
	- the same player will not be switched two times in a row to balance
	- team player difference can be set for balancing
	- Admins are immune from being team switched to balance

* ClanTag Protection Addon (addon_dodtms_clantagprotect.sp/.smx)
	- protect your clantag from being abused by public players
	- choose to rename, kick or even ban offenders
	- ability to force clantag usage on clanmembers

* ClassRestrictions Addon (addon_dodtms_classrest.sp/.smx)
	- allow admins to select limited/full classes
	- lock classes until there's X players on the server
	- remove classes' primary weapons on death to prevent circumventing the limits
	- enforce class limits and force players to change class after changing limits
	- block quick-class-switching within spawn area
	- Admin can use any class any time

* HighPingKicker Addon (addon_dodtms_highpingkicker.sp/.smx)
	- checks "Scoreboard"-ping, no faulty ping-calculations!
	- set maximum allowed ping and checking time
	- ability to disable ping-checking for constantly low ping players
	- only kick high pingers if there's X players on the server
	- Admins are immune from being kicked for high ping

* Player/TeamMenu Addon (addon_dodtms_playerteammenu.sp/.smx)
	- encourage, slay (even in spawn area) and team switch players by menu
	- encourage, swap and mix the teams
	- Admins vs. Public feature
	- Admins are immune from being target by other admins
	- Admins can be allowed to self-target

* RoundEnd Events Addon (addon_dodtms_roundendevents.sp/.smx)
	- automatically swap the teams after X rounds
	- automatically mix the teams after X consecutive won rounds
	- displays stats box with casualties for both teams and time needed to win

* SecretSpectate Addon (addon_dodtms_secretspectate.sp/.smx)
	- join team spectators while still being displayed on your team
	- observe players in question without them noticing
	- get back to your team without anyone noticing either

* TK Revenge Addon (addon_dodtms_tkrevenge.sp/.smx)
	- Spawn-/Melee-/Grenade-/Rampage-TeamKills can be handled different
	- Revenge Menu can be customized (Forgive/DONT Forgive/Slap/Slay)
	- TK-count can be saved and loaded through map-changes and even disconnects
	- Players can be kicked/banned when reaching set max TK-Count
	- TK-Count can be lowered with capping flags / killing enemies
	- already dead team killers can be slayed after respawning



3) Requirements:
================

* a gameserver running Day of Defeat: Source
* MetaMod:Source 1.7.X
* SourceMod 1.2.X and higher (SM 1.3 is supported!)



4) Installation instructions:
=============================

* as you're reading this you already unpacked the archive!

A] Basic Installation:
----------------------
For novice users this method is recommended!

* upload the "dod" folder into the "orangebox"-folder on your gameserver
* reboot your gameserver and enjoy!


B] Advanced Installation:
-------------------------
For advanced users this method is recommended!

* browse to the folder "\dod\addons\sourcemod\scripting\include\" and open the
  file "dodtms_plteamaccess.inc" with a text-editor, you can edit the access-rights
  for the Player/TeamMenu commands in here! Save the file after editing!
* copy the whole content of the "\dod\addons\sourcemod\scripting\"-folder into your
  SourceMod's "scripting" folder and compile the plugins against your used version.
* browse to the folder "\dod\cfg\dod_teammanager_source\", you will find all config files
  for the base and the addons within that folder, edit the configs to fit your needs!
* upload your freshly compiled plugins to your gameserver and be sure to upload the
  rest of the files (translations, configs, etc..) into the appropriate folders as well!
* move the Addons you don't want to run into the "disabled"-folder.
* reboot your gameserver and enjoy!



5) Notes and special thanks:
============================

* for extended support and bug reports please join our community at www.dodsourceplugins.net,
  registration is free and easy and you'll find a lot more useful DoD:S Plugins there as well!
* special thanks to "vintage", "monkie" and "MaKTaiL" for the included translations
  and very special thanks to my sweet girlfriend that patiently allowed me to spend a lot of time
  with this huge project! Kadda, I love you!
* once again thanks to all Beta Tester that spend hours with testing the new features!
* we're still looking for translators for other languages, please contact us if you're willing
  to help us out, it will be much appreciated!


